// ==UserScript==
// @name        TestCX
// @namespace   https://*icx.cathaypacific.com*
// @include     https://*icx.cathaypacific.com/*
// @include     https://*cathaypacific.com/*

// @version     1
// @grant       GM_log
// @grant       GM_setClipboard
// ==/UserScript==

// var script = document.createElement("script");
// script.src = "https://apis.google.com/js/client.js?onload=checkAuth";
// document.getElementsByTagName("head")[0].appendChild(script);

var icsButton = document.createElement("input");
icsButton.type = "button";
icsButton.value = "GreaseMonkey - Convert ICS";
icsButton.onclick = showAlert;

var calButton = document.createElement("input");
calButton.type = "button";
calButton.value = "GreaseMonkey - Convert Google Calendar";
calButton.onclick = convertGoogleCalendar;

// var newHTML = document.createElement("input");
// newHTML.type = "button";
// newHTML.value = "Authorize access to Google Calendar API";
// newHTML.onclick = handleAuthClick;

//newHTML.innerHTML   = '             \
//<div id="authorize-div" style="display: inline">\
//      <span>Authorize access to Google Calendar API</span>\
//      <button id="authorize-button" onclick="handleAuthClick(event)">\
//        Authorize\
//      </button>\
//    </div>\
//';
//document.body.appendChild (newHTML);


var cxTop = document.getElementById('bannervalue');
cxTop.parentNode.insertBefore(icsButton, cxTop);
cxTop.parentNode.insertBefore(calButton, cxTop);
cxTop.parentNode.insertBefore(newHTML, cxTop);

var clipboardText = "";
var clipboardTextGooCalendarList = new Array();

function showAlert() {

	parseTab(2);
	clipboardText += "\n";
	parseTab(3);

	clipboardText = "BEGIN:VCALENDAR\n\n" + clipboardText + "END:VCALENDAR\n";
	GM_setClipboard(clipboardText, 'text');
	alert('Clipboard Updated, please paste as .ics file');
}

function parseTab(tabOrder) {
	var result = document.evaluate("/html/body/table/tbody/tr[2]/td[2]/div["
			+ tabOrder + "]/table/tbody/tr", document, null,
			XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);

	var i = 0;
	var cxDates = [];
	while ((row = result.snapshotItem(i)) != null) {
		// console.log( 'row ' + i + '-' + row.innerHTML);
		i++;

		// gets cells of current row
		var oCells = row.cells;

		// skip first two header rows
		if (i > 2 && oCells.length >= 13) {
			var j = 0;

			// 3rd cell may be a URL or G
			if (oCells.item(2).getElementsByTagName('a').length > 0) {
				cxDates[cxDates.length] = new CXDate(
						oCells.item(j++).innerHTML,
						oCells.item(j++).innerHTML,
						oCells.item(j++).getElementsByTagName('a')[0].innerHTML,
						oCells.item(j++).innerHTML, oCells.item(j++).innerHTML,
						oCells.item(j++).innerHTML, oCells.item(j++).innerHTML,
						oCells.item(j++).innerHTML, oCells.item(j++).innerHTML,
						oCells.item(j++).innerHTML, oCells.item(j++).innerHTML,
						oCells.item(j++).innerHTML, oCells.item(j++).innerHTML);
			} else {
				cxDates[cxDates.length] = new CXDate(
						oCells.item(j++).innerHTML, oCells.item(j++).innerHTML,
						oCells.item(j++).innerHTML, oCells.item(j++).innerHTML,
						oCells.item(j++).innerHTML, oCells.item(j++).innerHTML,
						oCells.item(j++).innerHTML, oCells.item(j++).innerHTML,
						oCells.item(j++).innerHTML, oCells.item(j++).innerHTML,
						oCells.item(j++).innerHTML, oCells.item(j++).innerHTML,
						oCells.item(j++).innerHTML);
			}
		}
	}
	console.log('cxDates.length ' + cxDates.length);
	// TODO alfred
	// cxDates[cxDates.length - 3].printCXDate();
	// cxDates[cxDates.length - 2].printCXDate();
	// cxDates[cxDates.length - 1].printCXDate();
	console.log('Total ' + i + ' rows processed');

	// ********** aggregate cxDates into cxFlights **********

	var cxFlight = null;
	var cxFlights = [];
	for (i = 0; i < cxDates.length; i++) {
		cxDate = cxDates[i];

		if (cxDate.isDepartfromHKG() || cxDate.isStandby()) {
			if (cxFlight != null) {
				// close this group
				cxFlights[cxFlights.length] = cxFlight;
			}
			cxFlight = new CXFlight();
		}
		if (cxDate.blockHours != "") {
			cxFlight.addCXDate(cxDate);
		}
	}
	// close the last group
	if (cxFlight != null) {
		cxFlights[cxFlights.length] = cxFlight;
	}
	// ********** loop the cxFlights **********
	console.log('cxFlight.length ' + cxFlights.length);
	for (i = 0; i < cxFlights.length; i++) {
		cxFlight = cxFlights[i];
		console.log("Flight " + i + " - \n" + cxFlight.toFlightString());
		console.log("Flight " + i + " - \n" + cxFlight.formatFlightToGooCalendar());
		clipboardText += cxFlight.formatFlightToICS();
		clipboardTextGooCalendarList.push(cxFlight.formatFlightToGooCalendar());
	}	
}

function CXFlight() {
	this.cxDates = [];
	this.addCXDate = addCXDate;
	this.toFlightString = toFlightString;
	this.formatFlightToICS = formatFlightToICS;
	this.formatFlightToGooCalendar = formatFlightToGooCalendar;
}
function addCXDate(cxDate) {
	this.cxDates[this.cxDates.length] = cxDate;
}
function toFlightString() {
	var result = "";
	for (var i = 0; i < this.cxDates.length; i++) {
		cxDate = this.cxDates[i];
		result += "\\n " + cxDate.toDateString();
	}
	return result;
}
function formatFlightToICS() {
	var lastFlightdate="";
	for (var i = this.cxDates.length-1; i >=0 ; i--) {
		cxDate = this.cxDates[i];
		if (cxDate.date != "") {
			lastFlightdate = cxDate.date;
			break;
		}
	}

	var result = "BEGIN:VEVENT\n";
	result += "DTSTART;VALUE=DATE:"+formatDate(parseDate(this.cxDates[0].date))+"\n";
	result += "DTEND;VALUE=DATE:"+formatDate(getNextDate(parseDate(lastFlightdate)))+"\n";
	result += "SUMMARY:"+this.cxDates[0].formatDuty()+"\n";
	result += "DESCRIPTION:"+this.toFlightString()+"\n";
	result += "CATEGORIES:CX\n";
	result += "X-MICROSOFT-CDO-BUSYSTATUS:FREE\n";
	result += "END:VEVENT\n\n";
	return result;
}

function formatFlightToGooCalendar() {
	var lastFlightdate="";
	for (var i = this.cxDates.length-1; i >=0 ; i--) {
		cxDate = this.cxDates[i];
		if (cxDate.date != "") {
			lastFlightdate = cxDate.date;
			break;
		}
	}
	var result = {
    			   'summary': this.cxDates[0].formatDuty(),
    			   'description': this.toFlightString(),
    			   'start': {
    			     'date': formatDateGooCal(parseDate(this.cxDates[0].date))
    			   },
    			   'end': {
    			     'date': formatDateGooCal(getNextDate(parseDate(lastFlightdate)))
    			   }
    			 }	;
	//return JSON.stringify(result);
	return result;
}

function parseDate(dateStr_ddmmyyyy) {
	var parts = dateStr_ddmmyyyy.split('-');
	var d = new Date(parts[1] + " " + parts[0] + ", 20"+parts[2] );
	return d;
}
function formatDate(d) {
	var newDateStr = d.getFullYear()+""+pad(d.getMonth()+1)+""+pad(d.getDate());
	return newDateStr;
}
function formatDateGooCal(d) {
	var newDateStr = d.getFullYear()+"-"+pad(d.getMonth()+1)+"-"+pad(d.getDate());
	return newDateStr;
}
function getNextDate(d) {
	var tmr = d;
	tmr.setDate(d.getDate()+1);
	return tmr;
}
function pad(number) {
	if (number<=9) {
		number = ("0"+number);
	}
	return number;
}

function CXDate(date, weekday, duty, sd, sectorFrom, sectorTo, aircraftType,
		dutyStart, depTime, arrTime, dutyEnd, dutyPeriod, blockHours) {
	// remove whitespace from both sides of a string:
	this.date = date.trim();
	this.weekday = weekday.trim();
	this.duty = duty.trim();
	this.sd = sd.trim();
	this.sectorFrom = sectorFrom.trim();
	this.sectorTo = sectorTo.trim();
	this.aircraftType = aircraftType.trim();
	this.dutyStart = dutyStart.trim();
	this.depTime = depTime.trim();
	this.arrTime = arrTime.trim();
	this.dutyEnd = dutyEnd.trim();
	this.dutyPeriod = dutyPeriod.trim();
	this.blockHours = blockHours.trim();
	// function call
	this.toDateString = toDateString;
	this.isDepartfromHKG = isDepartfromHKG;
	this.isStandby = isStandby;
	this.formatDuty = formatDuty;
}
function toDateString() {
	var result = this.date + " " + this.weekday + " " + this.duty + " "
			+ this.sd + " " + this.sectorFrom + " " + this.sectorTo + " "
			+ this.aircraftType + " " + this.dutyStart + " " + this.depTime
			+ " " + this.arrTime + " " + this.dutyEnd + " " + this.dutyPeriod
			+ " " + this.blockHours;
	return result;
}
function isDepartfromHKG() {
	return this.sectorFrom == "HKG";
}
function isStandby() {
	return this.duty.indexOf("R")== 0;
}
function formatDuty() {
	if (this.isStandby()) {
		return "CX Standby " + this.duty;
	} else {
		return "CX" + parseInt(this.duty,10);
	}
}

function convertGoogleCalendar() {
	
	clipboardTextGooCalendarList = new Array();
	
	parseTab(2);
	clipboardText += "\n";
	parseTab(3);
		
	// loadCalendarApi();
	
	var clipboardTextGooCalendarText = JSON.stringify(clipboardTextGooCalendarList);	
	GM_setClipboard(clipboardTextGooCalendarText, 'text');
	alert('Clipboard Updated for Google Calendar, clipboardTextGooCalendar');
}











//******************


// Your Client ID can be retrieved from your project in the Google
// Developer Console, https://console.developers.google.com
// TODO var CLIENT_ID = '<YOUR_CLIENT_ID>';
var CLIENT_ID = '531488958143-akl328a6c6trltjhaipnbbb0oudkbnt1.apps.googleusercontent.com';
var SCOPES = ["https://www.googleapis.com/auth/calendar.readonly", "https://www.googleapis.com/auth/calendar"];

// ...
